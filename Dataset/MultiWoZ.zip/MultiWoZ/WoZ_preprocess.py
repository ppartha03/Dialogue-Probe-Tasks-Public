import os
import numpy as np
import json
import _pickle as cPickle
import argparse
from nltk.tokenize import word_tokenize
from copy import deepcopy
import math
import random
import csv
import string

parser = argparse.ArgumentParser()
parser.add_argument('--type',default = 'train')
args = parser.parse_args()
data_directory = './'
fp = open(os.path.join(data_directory,'data.json'))
mid_freq = open('./mid_freq_multiwoz.txt','r').readlines()
mid_freq = [w.strip() for w in mid_freq]
raw_data = json.load(fp)
task_count = {}

#random.seed(1234) # Train
#random.seed(6000) # Valid
random.seed(50000) # Test
def getID(lettersCount=4, digitsCount=3):
    sampleStr = ''.join((random.choice(string.ascii_letters) for i in range(lettersCount)))
    sampleStr += ''.join((random.choice(string.digits) for i in range(digitsCount)))

    # Convert string to list and shuffle it to mix letters and digits
    sampleList = list(sampleStr)
    random.shuffle(sampleList)
    finalString = ''.join(sampleList)
    return finalString

def recur(level, key, root, D = {}, D_local = {}):
    global task_count
    if key != '' and len(key.split('#')) < 2:
      if key.split('#')[0] not in task_count:
        task_count[key.split('#')[0]] = 1
      else:
        task_count[key.split('#')[0]] += 1
    if 'dict' not in str(type(level)):
      return True
    else:
      keys = list(level.keys())
      for k in keys:
        key = root + '#' + k
        if 'dict' not in str(type(level[k])):
          if 'list' not in str(type(level[k])) and level[k] != '' and len(
              level[k]) != 0 and level[k] != 'not mentioned':
            if key not in D:
              D_local.update({key: level[k]})
              D.update({key: level[k]})
        recur(level[k], k, key, D, D_local)
        key = root
    return D_local, D

def overlap(stats):
    overlap = []
    slot_names = []
    for k, occurrences in stats.items():
        if len(occurrences) > 1:
          tasks = []
          utterances = []
          for occ in occurrences:
            tasks += [occ['task']]
            utterances += [occ['utterance']]
            overlap += [{
                'slot': k,
                'tasks': tasks,
                'utterances': utterances
                }]
            slot_names+=[k]
    if len(slot_names):
        slot_names = '\t'.join(list(set(slot_names)))
    else:
        slot_names = 'none'
    return overlap,slot_names

def get_data(file_,acts,writer):
    raw_data[file_]['goal']['message'] = ' '.join(
        raw_data[file_]['goal']['message']).replace('</span>', '')
    raw_data[file_]['goal']['message'] = raw_data[file_]['goal'][
        'message'].replace('<span class=\'emphasis\'>', '')
    message = word_tokenize(raw_data[file_]['goal']['message'])
    message_ = []
    Dialog = {}
    for line in message:
      line_ = line.replace('.', ' <eos> ')
      l = []
      for word in word_tokenize(line):
        l += [word.lower().strip()]
      message_ += l
    D_global = {}
    tc_local = {}
    max_ut_len = 0
    user_history = []
    dial_topic = 'more_information'
    all_topics = []
    for i in range(len(raw_data[file_]['log'])):
      text = raw_data[file_]['log'][i]['text']
      text_ = []
      if i%2==0:
          local_graph = {}
      for token in word_tokenize(text):
        text_ += [token.lower().strip()]
      if len(text_) > max_ut_len:
        max_ut_len = len(text_)
      D_local = {}
      if i < len(raw_data[file_]['log'])-1:
        D_local, D_global = recur(raw_data[file_]['log'][i + 1]['metadata'], '',
                                  '', deepcopy(D_global), D_local)
        if len(D_local) > 0:

          for k_ in D_local.keys():
            task = k_.split('#')[1]
            slot = k_.split('#')[-1]
            if slot not in tc_local:
              tc_local[slot] = [{'utterance': i, 'task': task}]
            else:
              tc_local[slot] += [{'utterance': i, 'task': task}]
            if task not in all_topics:
                dial_topic = task
            all_topics+=[task]
      else:
        D_local = {}
      if i == 0:
        user_history+=text_+['<eou>']
        local_graph = D_local
      else:
        def myround(x, base=20):
            return str(int(base * max(1,math.ceil(x/base))/20))
        if i % 2:
          overlap_info,repeats = overlap(deepcopy(tc_local))
          c_id = getID()
          if str(int((i+1)/2)) in acts:
              if 'dict' in str(type(acts[str(int((i+1)/2))])):
                  actions = '\t'.join(list(acts[str(int((i+1)/2))].keys()))
                  entity_slots = ''
                  entity_values = ''
                  for ents,vals in list(acts[str(int((i+1)/2))].values())[0]:
                      entity_slots+=ents + '\t'
                      entity_values+=vals + '\t'
              else:
                  actions = 'No_Annotations'
                  entity_slots = 'No_Annotations'
                  entity_values = 'No_Annotations'

          else:
              actions = 'No_Annotations'
              entity_slots = 'No_Annotations'
              entity_values = 'No_Annotations'

          local_slots = ''
          local_values = ''
          for k,v in local_graph.items():
              local_slots += k + '\t'
              local_values += v + '\t'
          if local_slots == '':
              local_slots = 'none'
          if local_values == '':
              local_values = 'none'
          global_slots = ''
          global_values = ''
          for k,v in D_global.items():
              global_slots += k + '\t'
              global_values += v + '\t'
          if global_slots == '':
              global_slots = 'none'
          if global_values == '':
              global_values = 'none'
          if len(all_topics) == 0:
              all_topics_str = 'no_intent'
          else:
              all_topics_str = '\t'.join(list(set(all_topics)))
          ismultopic = '0'
          if len(set(all_topics)) > 1:
              ismultopic = '1'
          mid_freq_word = 'notpresent'
          for tw in text_:
              if tw in mid_freq:
                  mid_freq_word = tw
                  break
          d = {'contextID': c_id,'filename':file_.split('.')[0],'UtteranceIndex':i,'Target': ' '.join(text_), 'Context':' '.join(user_history),'RecentSlots':local_slots,'RecentValues':local_values,\
          'NumRecentInfo':len(local_graph), 'ResponseLength':len(text_),'UtteranceLoc':myround(i*100/len(raw_data[file_]['log'])),'NumRepeatSlots':len(overlap_info)//2, \
          'RepeatInfo': repeats, 'WordCont': mid_freq_word, 'RecentTopic': dial_topic, 'AllTopics':all_topics_str, 'NumAllTopics':str(len(set(all_topics))), 'NumAllInfo':len(D_global),'AllSlots':global_slots, \
          'AllValues':global_values, 'ActionSelect':actions,'EntitySlots':entity_slots, 'EntityValues': entity_values, 'IsMultiTask':ismultopic
          }
          writer.writerow(d)
          user_history+=text_+['<eou>']
        else:
          user_history+=text_+['<eou>']
          local_graph = D_local
    #return Dialog


if __name__ == '__main__':
    Files = list(raw_data.keys())
    Dataset = {}
    in_ = 0
    acts = json.load(open('dialogue_acts.json','r'))
    f_dev = open(os.path.join(data_directory,'valListFile.json'))
    dev_files = [line.strip() for line in f_dev.readlines()]
    f_test = open(os.path.join(data_directory,'testListFile.json'))
    test_files = [line.strip() for line in f_test.readlines()]
    train_files = [f for f in Files if f not in dev_files and f not in test_files]
    print(len(train_files),len(test_files))

    if args.type == 'train':
        dialogue_files = train_files
    elif args.type == 'valid':
        dialogue_files = dev_files
    else:
        dialogue_files = test_files
    fieldnames=['contextID','AllTopics','filename', 'UtteranceIndex', 'Context', 'Target', 'ResponseLength', 'UtteranceLoc','RepeatInfo','RecentTopic','RecentSlots', 'RecentValues', \
     'NumRecentInfo','AllValues', 'AllSlots', 'NumAllInfo','NumRepeatSlots', 'NumAllTopics', 'IsMultiTask', \
     'EntitySlots', 'EntityValues', 'ActionSelect', 'WordCont']
    target = open("MultiWoZ_"+args.type+".csv", "w")
    writer = csv.DictWriter(target, fieldnames=fieldnames)
    #writer.writerow(dict(zip(fieldnames, fieldnames)))
    for f in dialogue_files:
        print(f)
        get_data(f,acts[f.split('.')[0]],writer)
        in_+=1
        print(in_,'/',len(dialogue_files))
    target.close()
