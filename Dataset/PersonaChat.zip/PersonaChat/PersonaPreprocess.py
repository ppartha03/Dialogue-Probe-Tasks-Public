from nltk.tokenize import word_tokenize as tokenizer
import os
import json
import math
import random
import csv
import string

mid_freq = open('./mid_freq_personachat.txt','r').readlines()
mid_freq = [w.strip() for w in mid_freq]
stopwords = open('./high_freq_personainfo.txt','r').readlines()
stopwords = [w.strip() for w in stopwords]
def myround(x, base=20):
    return str(int(base * max(1,math.ceil(x/base))/20))

def getID(lettersCount=4, digitsCount=3):
    sampleStr = ''.join((random.choice(string.ascii_letters) for i in range(lettersCount)))
    sampleStr += ''.join((random.choice(string.digits) for i in range(digitsCount)))

    # Convert string to list and shuffle it to mix letters and digits
    sampleList = list(sampleStr)
    random.shuffle(sampleList)
    finalString = ''.join(sampleList)
    return finalString

def createCSV(dataset,type):
    fieldnames=['ContextID','filename','UtteranceIndex', 'Context', 'Target', 'ResponseLength','UtteranceLoc','PersonalInfo', 'WordCont']
    target = open("PersonaChat_"+type+".csv", "w")
    writer = csv.DictWriter(target, fieldnames=fieldnames)
    #writer.writerow(dict(zip(fieldnames, fieldnames)))
    for dial_ind in range(len(dataset)):
        print(dial_ind,'/',len(dataset))
        dial_length = len(dataset[dial_ind]['utterances'])
        personality = dataset[dial_ind]['personality']
        tokens_persona = []
        for sent in personality:
            for word in sent.split():
                if word not in stopwords:
                    tokens_persona +=[word]
        for u_id in range(len(dataset[dial_ind]['utterances'])):
            c_id = getID()
            machine = dataset[dial_ind]['utterances'][u_id]['candidates'][-1]
            context = ' <eou> '.join(dataset[dial_ind]['utterances'][u_id]['history'])
            mid_freq_word = 'notpresent'
            for tw in machine.split():
                if tw in mid_freq:
                    mid_freq_word = tw
                    break
            d = {'ContextID': c_id,'filename':str(dial_ind),'UtteranceIndex':u_id,'Target': machine, 'Context':context, \
            'ResponseLength':len(machine.split()),'UtteranceLoc':myround(u_id*100/dial_length), \
            'PersonalInfo': ' '.join(tokens_persona), 'WordCont': mid_freq_word
            }
            writer.writerow(d)
    target.close()


def get_dataset(data_folder = '.'):
    """ Get tokenized PERSONACHAT dataset from S3 or cache."""
    personachat_file = os.path.join(data_folder,'personachat.json')
    with open(personachat_file, "r", encoding="utf-8") as f:
        dataset = json.loads(f.read())
    for k,v in dataset.items():
        createCSV(v,k)

    #logger.info("Tokenize and encode the dataset")
if __name__ == '__main__':
    get_dataset()
